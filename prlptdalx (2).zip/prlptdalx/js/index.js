const myLocalComponent = {
   data () {
    return {
      search: '',
     /*  seleccionar:{ }, */

      headers: [
          { text: 'Fecha de Nacimiento', value: 'd_nacimiento' },
          { text: 'Nombre', value: 'nombre' },
          { text: 'Area', value:'v_area'},
          { text: 'Cargo', value:'v_cargo'},
          { text: 'Sede', value:'COD_SUCURSAL'},
          { text: 'Sexo', value:'v_genero'},
      ],
      items: [],
     /*  seleccionado: " " */
    }
  
  },
  
  created: function(){
      this.getData()
  },
  methods: {
      getData : function(){
          var month = new Date();
          var dia_mes=moment(month).format('MM');
          axios.post('https://servpublico.maisondesante.org.pe/api/birthday', {nombres:"", dia_mes:dia_mes,type:2})
          .then(function(response){
              app.items=response.data;
              console.log('hola',response)
          })

      }
  },

}

var app = new Vue({
    el:'#app',
    data:{
        message:'por favor funciona :v',
        ventana:true,
        ventanilla: false,
        bcumpleaños:"",
       cumpleaños:[],
  url: "https://servpublico.maisondesante.org.pe/api",

  
  search: '',
 /*  seleccionar:{ }, */
 
  headers: [
  { text: 'Fecha de Nacimiento', value: 'd_nacimiento' },
  { text: 'Nombre', value: 'nombre' },
  { text: 'Area', value:'v_area'},
  { text: 'Cargo', value:'v_cargo'},
  { text: 'Sede', value:'COD_SUCURSAL'},
  { text: 'Sexo', value:'v_genero'},
  ],
  items: [],
/*   seleccionado: " "  */
    },
    mounted: function () {
  console.log("Hello from Vue!");
this.getCumpleaños();

  },
  components: {
    myLocalComponent: myLocalComponent,  
  },
    methods:{

     getCumpleaños : function (){
  var today = new Date();
  var dia_mes =moment(today).format("DD/MM"); 
  var mes= moment(today).format("MM");
/*   var funcion2= this.getData(); */

  const data = {
  nombres:"",
  dia_mes:dia_mes,
  type:1
  }
  var conexion = axios.post(this.url + "/birthday",data );
  conexion.then(function(response){
   app.cumpleaños = response.data;
 /*   funcion2; */
  })
  }, 

/*   getData : function(){
            var month = new Date();
            var dia_mes=moment(month).format('MM');
            const data2 = {
                nombres:"", 
                dia_mes:dia_mes,
                type:2
  }
            axios.post(this.url + "/birthday",data2)
            .then(function(response){
                app.items=response.data;
                console.log('hola',response)
            })

        }, */
        
  /*getMostrar: function(){
    var ventana =  ventana
    var ventanilla =  ventanilla
          if(Event.click === ventana){
            this.getCumpleaños();
          }
          else if(Event.click=== ventanilla)
          {
            this.getData();
          }
          else {
            return null;
          }
        } */

      },
    
    
  })

