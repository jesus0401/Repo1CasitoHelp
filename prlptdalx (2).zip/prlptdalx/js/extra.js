/* 
const appi = new Vue({
    el: '#aplication',
    
     data : {
        ventana:true,
        ventanilla: false,
     
        search: '',
       /*  seleccionar:{ }, */
       
        headers: [
            { text: 'Fecha de Nacimiento', value: 'd_nacimiento' },
            { text: 'Nombre', value: 'nombre' },
            { text: 'Area', value:'v_area'},
            { text: 'Cargo', value:'v_cargo'},
            { text: 'Sede', value:'COD_SUCURSAL'},
            { text: 'Sexo', value:'v_genero'},
        ],
        items: [],
       /*  seleccionado: " " */
   
    
    },
    
    created: function(){
        this.getData()
    },
     
    methods: { 
     
        getData : function(){
            var month = new Date();
            var dia_mes=moment(month).format('MM');
            axios.post('https://servpublico.maisondesante.org.pe/api/birthday', {nombres:"", dia_mes:dia_mes,type:2})
            .then(function(response){
                appi.items=response.data;
                console.log('hola',response)
            })

        }
    },
     
     /* https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js
     https://unpkg.com/babel-polyfill/dist/polyfill.min.js
     https://unpkg.com/vue/dist/vue.js
     https://unpkg.com/vuetify@1.0.4/dist/vuetify.min.js
     */
  })  	 */